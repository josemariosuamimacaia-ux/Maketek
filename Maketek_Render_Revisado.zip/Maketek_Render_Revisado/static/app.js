document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("[data-confirm]").forEach(form => {
    form.addEventListener("submit", event => {
      if (!window.confirm(form.dataset.confirm || "Confirmas esta operação?")) event.preventDefault();
    });
  });
  document.querySelectorAll(".dismiss").forEach(button => {
    button.addEventListener("click", () => button.closest(".flash")?.remove());
  });
  const kind = document.getElementById("kind");
  const label = document.getElementById("quantityLabel");
  const help = document.getElementById("quantityHelp");
  const quantity = document.getElementById("quantity");
  function updateMovementHelp() {
    if (!kind || !label || !help || !quantity) return;
    if (kind.value === "entrada") {
      label.textContent = "Quantidade a adicionar";
      help.textContent = "Indica quantas unidades entraram.";
      quantity.min = "1";
    } else if (kind.value === "saida") {
      label.textContent = "Quantidade a retirar";
      help.textContent = "A quantidade não pode exceder o saldo atual.";
      quantity.min = "1";
    } else {
      label.textContent = "Quantidade física encontrada";
      help.textContent = "O sistema regista a diferença face ao saldo atual.";
      quantity.min = "0";
    }
  }
  kind?.addEventListener("change", updateMovementHelp);
  updateMovementHelp();
});